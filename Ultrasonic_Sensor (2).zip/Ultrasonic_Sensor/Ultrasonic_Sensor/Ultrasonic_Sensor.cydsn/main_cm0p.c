/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <control.h>


/* Interrupts ------------------------------------------------------------------------------- */
void ultraone()
{
    timer_SetCounter(0);
    NVIC_ClearPendingIRQ(startint_cfg.intrSrc);
}

void ultradone()
{
    time = timer_GetCounter();
    //array1count = average(array1, array1count, 1);
    NVIC_ClearPendingIRQ(int_stop_cfg.intrSrc);
}

void ultradone_Two()
{
    time_two = timer_GetCounter();
    //array2count = average(array2, array2count, &time_two);
    NVIC_ClearPendingIRQ(int_stop_1_cfg.intrSrc);
}

void ultradone_Three()
{
    time_three = timer_GetCounter();
    //array3count = average(array3, array3count, &time_three);
    NVIC_ClearPendingIRQ(int_stop_2_cfg.intrSrc);
}

void cycles()
{
    total_Turns_One++;
    NVIC_ClearPendingIRQ(RPM_Count_cfg.intrSrc);
}

void cyclestwo()
{
    total_Turns_Two++;
    NVIC_ClearPendingIRQ(RPM_Count_Two_cfg.intrSrc);
}


/* Main ---------------------------------------------------------------------------------------- */
int main(void)
{
    /* Enable CM4.  CY_CORTEX_M4_APPL_ADDR must be updated if CM4 memory layout is changed. */
    //Cy_SysEnableCM4(CY_CORTEX_M4_APPL_ADDR); 

    
    char stuff[32];
    
    bool RFIDread = false;
    
    enum steps cycle = none;
    enum ID person1 = Room;
    
    uint8 pin = 0;
    
    clear_array(user);
    
    foward_Start();
    reverse_Start();
    
    foward_1_Start();
    reverse_1_Start();
    
    PWM_Start();
    UART_Start();
    I2C_Start();
    
    //Cy_SCB_UART_PutString(UART_HW, "System set up correctly\r");
    timer_Start();
    
    Cy_SysInt_Init(&RPM_Count_cfg, cycles);
    Cy_SysInt_Init(&RPM_Count_Two_cfg, cyclestwo);
    
    Cy_SysInt_Init(&startint_cfg, ultraone);
    Cy_SysInt_Init(&int_stop_cfg, ultradone);
    Cy_SysInt_Init(&int_stop_1_cfg, ultradone_Two);
    Cy_SysInt_Init(&int_stop_2_cfg, ultradone_Three);
    
    NVIC_ClearPendingIRQ(RPM_Count_cfg.intrSrc);
    NVIC_ClearPendingIRQ(RPM_Count_Two_cfg.intrSrc);
    
    NVIC_ClearPendingIRQ(int_stop_cfg.intrSrc);
    NVIC_ClearPendingIRQ(int_stop_1_cfg.intrSrc);
    NVIC_ClearPendingIRQ(int_stop_2_cfg.intrSrc);
    NVIC_ClearPendingIRQ(startint_cfg.intrSrc);
    
    NVIC_EnableIRQ((IRQn_Type)RPM_Count_cfg.intrSrc);
    NVIC_EnableIRQ((IRQn_Type)RPM_Count_Two_cfg.intrSrc);
    
    NVIC_EnableIRQ((IRQn_Type)startint_cfg.intrSrc);
    NVIC_EnableIRQ((IRQn_Type)int_stop_cfg.intrSrc);
    NVIC_EnableIRQ((IRQn_Type)int_stop_1_cfg.intrSrc);
    NVIC_EnableIRQ((IRQn_Type)int_stop_2_cfg.intrSrc);
    
    Cy_SCB_UART_Enable(UART_HW);
    
    
    __enable_irq(); /* Enable global interrupts. */
    
    SAMConfig();
    
    for(;;)
    {
        //sprintf(stuff, "left ultra:%d   middle ultra:%d    right ultra:%d   IR 1:%d   IR 2:%d    RFID:%d   \r", time_three, time_two, time, total_Turns_One, total_Turns_Two, uid[2]);
        //sprintf(stuff, "time:%d     power:%d         \r", time, powerlevel(time));
//        Cy_SCB_UART_PutString(UART_HW, stuff);
//        CyDelay(50);
                 

//        RFID_Read();

        pin = 0;
        pin = Cy_GPIO_Read(button_go_PORT, button_go_NUM);
        
        if(pin == 1)
        {
            //CyDelay(10000);
            if(firstroom[direction] != 0)
            {
                clear_sensors();
                godirection(firstroom, direction, firstside);
                CyDelay(1000);
                direction++;
            }
            else if(firstroom[direction] == 0)
            {
                direction++;
                turn90(firstroom[direction]);
                CyDelay(1000);
                direction++;
            }
            else
            {
                stop();
                cycle = none;
                //pin =1;
            }
        }
        if(cycle == none)
        {
            stop(); 
        }
//        
//        
    }
}


/* Functions----------------------------------------------------------------- */
void clear_array(char clean[])
{
    int x;
    for(x = 0; x<ARRAYLENGTH; x++)
    {
        clean[x] = '\0';
    }
}


void clear_sensors(void)
{
    total_Turns_One = 0;
    total_Turns_Two = 0;
}

void turn90(int direction)
{
    if(direction == 1)
    {
        Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, 0);
        Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, MOTORPOWER);
        
        Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, MOTORPOWER);
        Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
        
        while((total_Turns_One <= 6) || (total_Turns_Two <= 6))
        {
        }
    }
    if(direction == 2)
    {
        Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, MOTORPOWER);
        Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, 0);
        
        Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
        Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, MOTORPOWER);
        
        while((total_Turns_One <= 6) || (total_Turns_Two <= 6))
        {
        }
    }
    stop();
}

void forward(void)
{
    Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, MOTORPOWER);
    Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, MOTORPOWER);
    
    Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
    Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
}

void stop(void)
{
    Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, 0);
    Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, 0);
    
    Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
    Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
}

void godirection(const int distance[], int direction, const int wall[])
{
    forward();
    while((distance[direction] > total_Turns_One) || (distance[direction] > total_Turns_Two))
    {
        if(wall[direction] != 0)
        {
            //wallcheck(wall);
        }
        //obstructioncheck(wall);
    }
    stop();
    clear_sensors();
}

void wallcheck(const int wall[])
{
    if(wall[direction] == LEFT)
    {
        if(time < WALLCLOSE)
        {
            Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, MOTORPOWER);
            Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, powerlevel(time));
    
            Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
            Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
        } 
        if(time > WALLFAR)
        {
            Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, powerlevel(time));
            Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, MOTORPOWER);
    
            Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
            Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
        }
    }
    if(wall[direction] == RIGHT)
    {
        if(time_two < WALLCLOSE)
        {
            Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, MOTORPOWER - MOTORWALL);
            Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, MOTORPOWER);
    
            Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
            Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
        } 
        if(time_two > WALLFAR)
        {
            Cy_TCPWM_PWM_SetCompare0(foward_1_HW, foward_1_CNT_NUM, MOTORPOWER);
            Cy_TCPWM_PWM_SetCompare0(foward_HW, foward_CNT_NUM, MOTORPOWER - MOTORWALL);
    
            Cy_TCPWM_PWM_SetCompare0(reverse_1_HW, reverse_1_CNT_NUM, 0);
            Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, 0);
        }
    }
}

void obstructioncheck(const int wall[])
{
    if(time_three < STOPDIST)
    {
        if(wall[direction] == LEFT)
        {
            turn90(RIGHT);
            forward();
            while((time < TURNDIST) || (time_three > STOPDIST));
            stop();
            if(time > TURNDIST)
            {
                turn90(LEFT);
                forward();
                CyDelay(1000);
                while(time_three > STOPDIST || time < TURNDIST);
                if(time > TURNDIST)
                {
                    turn90(LEFT);
                    forward();
                    CyDelay(1000);
                    while(time_three > STOPDIST);
                    turn90(RIGHT);
                    forward();
                }
                else{cycle = none;}
            }
            else
            {
                cycle = none;
            }
        }
    }
    if(wall[direction] == RIGHT)
    {
        turn90(LEFT);
        forward();
        while((time_two < TURNDIST) || (time_three > STOPDIST));
        stop();
        if(time_two > TURNDIST)
        {
            turn90(RIGHT);
            forward();
            CyDelay(1000);
            while(time_three > STOPDIST || time_two < TURNDIST);
            if(time > TURNDIST)
            {
                turn90(RIGHT);
                forward();
                CyDelay(1000);
                while(time_three > STOPDIST);
                turn90(LEFT);
                forward();
            }
            else{cycle = none;}
        }
        else
        {
            cycle = none;
        }
    }
}

int average(int array1[], int arraycount,int ultra_num)
{
    int currenttime;
    switch (ultra_num)
    {
        case 1:
            currenttime = time;
            break;
        case 2:
            currenttime = time_two;
            break;
        case 3:
            currenttime = time_three;
            break;
    }
    
    int counter = 0;
    array1[arraycount] = currenttime;
    currenttime = 0;
    while(counter < 32)
    {
        currenttime += array1[counter];
        counter++;
    }
    currenttime = currenttime/32;
    arraycount++;
    if(arraycount >= 32)
    {
        arraycount = 0;
    }
    switch (ultra_num)
    {
        case 1:
            time = currenttime;
            break;
        case 2:
            time_two = currenttime;
            break;
        case 3:
            time_three = currenttime;
            break;
    }
    return arraycount;
}

int powerlevel(float wall)
{
    float power;
    if(wall >= WALLFAR)
    {
        power = ((wall-WALLFAR)/8000) * (65000);
        power = (int)(65000 - power);
    }
    else
    {
        power = (wall/WALLFAR) * (65000);
        power = (int)power;
    }
    return power;
}

void RFID_Read(void)
{
    if(0 != readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength))
    {
        switch(uid[2])
        {
            case 5:
                Cy_GPIO_Write(lockbox_PORT, lockbox_NUM, HIGH);
                CyDelay(3000);
                Cy_GPIO_Write(lockbox_PORT, lockbox_NUM, LOW);
                break;
            case 142:
                break;
            case 7:
                break;
            case 247:
                break;
            case 40:
                break;
            case 45:
                break;
            case 14:
                break;
            case 217:
                break;
            case 49:
                break;
            case 89:
                break;
            case 94:
                break;
            case 155:
                break;
            case 25:
                break;
            case 53:
                break;
            case 245:
                break;
            case 220:
                break;
            case 141:
                break;
            case 11:
                break;
            case 60:
                break;
            case 136:
                break;
            case 41:
                break;
            case 232:
                break;
            case 200:
                break;
            case 192:
                break;
        }
    }
    
}