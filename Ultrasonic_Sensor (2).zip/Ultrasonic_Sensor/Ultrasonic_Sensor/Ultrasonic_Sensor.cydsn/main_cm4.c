/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "header01.h"

int main(void)
{
    uint8 pin = 0;
    __enable_irq(); /* Enable global interrupts. */
    
    I2C_1_Start();

    SAMConfig();
    
    for(;;)
    {
        pin = ((HIGH == Cy_GPIO_Read(button_PORT, button_NUM) ? HIGH : LOW));
        while(HIGH == Cy_GPIO_Read(button_PORT, button_NUM));
        
        if(pin == 1 && state == 0)
        {
            UserInterface();
            CyDelay(50);
            pin = 0;
        }
        if(state == 1 && pin == 1)
        {
            state = 0;
            Cy_GPIO_Write(LED_PORT, LED_NUM, LOW);
        }
        RFID_Read();
    }
}

void RFID_Read(void)
{
    if(0 != readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength))
    {
        switch(uid[2])
        {
            case 5:
                Cy_GPIO_Write(lockbox_PORT, lockbox_NUM, HIGH);
                Cy_GPIO_Write(LED_PORT, LED_NUM, HIGH);
                CyDelay(3000);
                state = 1;
                Cy_GPIO_Write(lockbox_PORT, lockbox_NUM, LOW);
                break;
        }
    }
    
}

void UserInterface(void)
{
            sprintf(user, "\r\nEnter Name\r\n");
            Cy_SCB_UART_PutString(UART_HW, user);
            data_Grab(Patient1.PatName);
            sprintf(user, "\r\nName entered: ");
            Cy_SCB_UART_PutString(UART_HW, user);
            Cy_SCB_UART_PutString(UART_HW, Patient1.PatName);
            sprintf(user, "\r\nEnter Room\r\n");
            Cy_SCB_UART_PutString(UART_HW, user);
            data_Grab(Patient1.PatRoom);
            sprintf(user, "\r\nRoom entered: ");
            Cy_SCB_UART_PutString(UART_HW, user);
            Cy_SCB_UART_PutString(UART_HW, Patient1.PatRoom);
            sprintf(user, "\r\nEnter Cube\r\n");
            Cy_SCB_UART_PutString(UART_HW, user);
            data_Grab(Patient1.PatCube);
            sprintf(user, "\r\nCube entered: ");
            Cy_SCB_UART_PutString(UART_HW, user);
            Cy_SCB_UART_PutString(UART_HW, Patient1.PatCube);
            sprintf(user, "\r\nEnter Time\r\n");
            Cy_SCB_UART_PutString(UART_HW, user);
            data_Grab(Patient1.PatTime);
            sprintf(user, "\r\nTime entered: ");
            Cy_SCB_UART_PutString(UART_HW, user);
            Cy_SCB_UART_PutString(UART_HW, Patient1.PatTime);
     
}

void data_Grab(char Patient[])
{
    uint8 x = 0;
    uint32 read_data = 0;
    while(read_data != 0x0D)
    {
        /* Check if there is a received character from user console */
        if (0UL != Cy_SCB_UART_GetNumInRxFifo(UART_HW))
        {
            /* Re-transmit whatever the user types on the console */
            read_data = Cy_SCB_UART_Get(UART_HW);
            while (0UL == Cy_SCB_UART_Put(UART_HW,read_data))
            {
            }
            Patient[x] = (char)read_data;
            x++;
        }
    }
}

static void SetDateTime(void)
{
    /* Variables used to store user input */
    char dateStr[MAX_LENGTH], monthStr[MAX_LENGTH], yearStr[MAX_LENGTH];
    char secStr[MAX_LENGTH], minStr[MAX_LENGTH], hourStr[MAX_LENGTH];
    
    /* Variables used to store date and time information */
    uint32_t date, month, year, sec, min, hour;
    
    printf("\r\nEnter new date (DD MM YY)\r\n");
    scanf("%s %s %s", dateStr, monthStr, yearStr);
    
    if(strlen(dateStr)<= VALID_DAY_LENGTH && strlen(monthStr)<= VALID_MONTH_LENGTH  && \
    (strlen(yearStr)<= VALID_SHORT_YEAR_LENGTH || strlen(yearStr)== VALID_LONG_YEAR_LENGTH ))
    {
        printf("\rEnter new time in 24-hour format (hh mm ss)\r\n");
        scanf("%s %s %s", hourStr, minStr, secStr);
        
        /* Convert string input to decimal */
        date    = atoi(dateStr);
        month   = atoi(monthStr);
        year    = atoi(yearStr);
        sec     = atoi(secStr);
        min     = atoi(minStr);
        hour    = atoi(hourStr);
        
        if(year > CY_RTC_MAX_YEAR) /* If user input 4 digits Year information, set 2 digits Year */
        {
            year = year % 100u;
        }
        
        if(ValidateDateTime(sec, min, hour, date, month, year))
        {
            /* Set date and time */
            if( Cy_RTC_SetDateAndTimeDirect(sec, min, hour, date, 
                month, year ) != CY_RTC_SUCCESS)
            {
                printf("Failed to update date and time\r\n");
                //PrintAvailableCommands();
            }
            else
            {
                printf("\r\nDate and Time updated !!\r\n");
                //PrintDateTime();
            }
        } 
    }
}

static bool ValidateDateTime(uint32_t sec, uint32_t min, uint32_t hour, \
                      uint32_t date, uint32_t month, uint32_t year)
{
    /* Variable used to store days in months table */
    static uint8_t daysInMonthTable[CY_RTC_MONTHS_PER_YEAR] = {CY_RTC_DAYS_IN_JANUARY,
                                                            CY_RTC_DAYS_IN_FEBRUARY,
                                                            CY_RTC_DAYS_IN_MARCH,
                                                            CY_RTC_DAYS_IN_APRIL,
                                                            CY_RTC_DAYS_IN_MAY,
                                                            CY_RTC_DAYS_IN_JUNE,
                                                            CY_RTC_DAYS_IN_JULY,
                                                            CY_RTC_DAYS_IN_AUGUST,
                                                            CY_RTC_DAYS_IN_SEPTEMBER,
                                                            CY_RTC_DAYS_IN_OCTOBER,
                                                            CY_RTC_DAYS_IN_NOVEMBER,
                                                            CY_RTC_DAYS_IN_DECEMBER};
    uint8_t daysInMonth;
    bool status = true;
        
    status &= CY_RTC_IS_SEC_VALID(sec);
    status &= CY_RTC_IS_MIN_VALID(min);
    status &= CY_RTC_IS_HOUR_VALID(hour);
    status &= CY_RTC_IS_MONTH_VALID(month);
    status &= CY_RTC_IS_YEAR_SHORT_VALID(year);
    
    if(status)
    {
        daysInMonth = daysInMonthTable[month - 1];
        
        if(IsLeapYear(year + CY_RTC_TWO_THOUSAND_YEARS) && (month == CY_RTC_FEBRUARY))
        {        
            daysInMonth++;
        }
        status &= (date > 0U) && (date <= daysInMonth);
    }
    return status;
}

static inline bool IsLeapYear(uint32_t year)
{
    return(((0U == (year % 4UL)) && (0U != (year % 100UL))) || (0U == (year % 400UL)));
}