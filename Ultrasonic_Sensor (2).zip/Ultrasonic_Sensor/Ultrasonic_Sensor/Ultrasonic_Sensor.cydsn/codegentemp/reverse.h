/*******************************************************************************
* File Name: reverse.h
* Version 1.0
*
* Description:
*  This file provides constants and parameter values for the reverse
*  component.
*
********************************************************************************
* Copyright 2016-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(reverse_CY_TCPWM_PWM_PDL_H)
#define reverse_CY_TCPWM_PWM_PDL_H

#include "cyfitter.h"
#include "tcpwm/cy_tcpwm_pwm.h"

   
/*******************************************************************************
* Variables
*******************************************************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t  reverse_initVar;
extern cy_stc_tcpwm_pwm_config_t const reverse_config;
/** @} group_globals */


/***************************************
*        Function Prototypes
****************************************/
/**
* \addtogroup group_general
* @{
*/
void reverse_Start(void);
__STATIC_INLINE cy_en_tcpwm_status_t reverse_Init(cy_stc_tcpwm_pwm_config_t const *config);
__STATIC_INLINE void reverse_DeInit(void);
__STATIC_INLINE void reverse_Enable(void);
__STATIC_INLINE void reverse_Disable(void);
__STATIC_INLINE uint32_t reverse_GetStatus(void);
__STATIC_INLINE void reverse_SetCompare0(uint32_t compare0);
__STATIC_INLINE uint32_t reverse_GetCompare0(void);
__STATIC_INLINE void reverse_SetCompare1(uint32_t compare1);
__STATIC_INLINE uint32_t reverse_GetCompare1(void);
__STATIC_INLINE void reverse_EnableCompareSwap(bool enable);
__STATIC_INLINE void reverse_SetCounter(uint32_t count);
__STATIC_INLINE uint32_t reverse_GetCounter(void);
__STATIC_INLINE void reverse_SetPeriod0(uint32_t period0);
__STATIC_INLINE uint32_t reverse_GetPeriod0(void);
__STATIC_INLINE void reverse_SetPeriod1(uint32_t period1);
__STATIC_INLINE uint32_t reverse_GetPeriod1(void);
__STATIC_INLINE void reverse_EnablePeriodSwap(bool enable);
__STATIC_INLINE void reverse_TriggerStart(void);
__STATIC_INLINE void reverse_TriggerReload(void);
__STATIC_INLINE void reverse_TriggerKill(void);
__STATIC_INLINE void reverse_TriggerSwap(void);
__STATIC_INLINE uint32_t reverse_GetInterruptStatus(void);
__STATIC_INLINE void reverse_ClearInterrupt(uint32_t source);
__STATIC_INLINE void reverse_SetInterrupt(uint32_t source);
__STATIC_INLINE void reverse_SetInterruptMask(uint32_t mask);
__STATIC_INLINE uint32_t reverse_GetInterruptMask(void);
__STATIC_INLINE uint32_t reverse_GetInterruptStatusMasked(void);
/** @} general */


/***************************************
*           API Constants
***************************************/

/**
* \addtogroup group_macros
* @{
*/
/** This is a ptr to the base address of the TCPWM instance */
#define reverse_HW                 (reverse_TCPWM__HW)

/** This is a ptr to the base address of the TCPWM CNT instance */
#define reverse_CNT_HW             (reverse_TCPWM__CNT_HW)

/** This is the counter instance number in the selected TCPWM */
#define reverse_CNT_NUM            (reverse_TCPWM__CNT_IDX)

/** This is the bit field representing the counter instance in the selected TCPWM */
#define reverse_CNT_MASK           (1UL << reverse_CNT_NUM)
/** @} group_macros */

#define reverse_INPUT_MODE_MASK    (0x3U)
#define reverse_INPUT_DISABLED     (7U)


/*******************************************************************************
* Function Name: reverse_Init
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_tcpwm_status_t reverse_Init(cy_stc_tcpwm_pwm_config_t const *config)
{
    return(Cy_TCPWM_PWM_Init(reverse_HW, reverse_CNT_NUM, config));
}


/*******************************************************************************
* Function Name: reverse_DeInit
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_DeInit(void)                   
{
    Cy_TCPWM_PWM_DeInit(reverse_HW, reverse_CNT_NUM, &reverse_config);
}

/*******************************************************************************
* Function Name: reverse_Enable
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Enable_Multiple() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_Enable(void)                   
{
    Cy_TCPWM_Enable_Multiple(reverse_HW, reverse_CNT_MASK);
}


/*******************************************************************************
* Function Name: reverse_Disable
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Disable_Multiple() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_Disable(void)                  
{
    Cy_TCPWM_Disable_Multiple(reverse_HW, reverse_CNT_MASK);
}


/*******************************************************************************
* Function Name: reverse_GetStatus
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_GetStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetStatus(void)                
{
    return(Cy_TCPWM_PWM_GetStatus(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_SetCompare0
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_SetCompare0() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetCompare0(uint32_t compare0)      
{
    Cy_TCPWM_PWM_SetCompare0(reverse_HW, reverse_CNT_NUM, compare0);
}


/*******************************************************************************
* Function Name: reverse_GetCompare0
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_GetCompare0() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetCompare0(void)              
{
    return(Cy_TCPWM_PWM_GetCompare0(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_SetCompare1
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_SetCompare1() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetCompare1(uint32_t compare1)      
{
    Cy_TCPWM_PWM_SetCompare1(reverse_HW, reverse_CNT_NUM, compare1);
}


/*******************************************************************************
* Function Name: reverse_GetCompare1
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_GetCompare1() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetCompare1(void)              
{
    return(Cy_TCPWM_PWM_GetCompare1(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_EnableCompareSwap
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_EnableCompareSwap() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_EnableCompareSwap(bool enable)  
{
    Cy_TCPWM_PWM_EnableCompareSwap(reverse_HW, reverse_CNT_NUM, enable);
}


/*******************************************************************************
* Function Name: reverse_SetCounter
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_SetCounter() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetCounter(uint32_t count)          
{
    Cy_TCPWM_PWM_SetCounter(reverse_HW, reverse_CNT_NUM, count);
}


/*******************************************************************************
* Function Name: reverse_GetCounter
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_GetCounter() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetCounter(void)               
{
    return(Cy_TCPWM_PWM_GetCounter(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_SetPeriod0
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_SetPeriod0() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetPeriod0(uint32_t period0)          
{
    Cy_TCPWM_PWM_SetPeriod0(reverse_HW, reverse_CNT_NUM, period0);
}


/*******************************************************************************
* Function Name: reverse_GetPeriod0
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_GetPeriod0() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetPeriod0(void)                
{
    return(Cy_TCPWM_PWM_GetPeriod0(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_SetPeriod1
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_SetPeriod1() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetPeriod1(uint32_t period1)
{
    Cy_TCPWM_PWM_SetPeriod1(reverse_HW, reverse_CNT_NUM, period1);
}


/*******************************************************************************
* Function Name: reverse_GetPeriod1
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_GetPeriod1() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetPeriod1(void)                
{
    return(Cy_TCPWM_PWM_GetPeriod1(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_EnablePeriodSwap
****************************************************************************//**
*
* Invokes the Cy_TCPWM_PWM_EnablePeriodSwap() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_EnablePeriodSwap(bool enable)
{
    Cy_TCPWM_PWM_EnablePeriodSwap(reverse_HW, reverse_CNT_NUM, enable);
}


/*******************************************************************************
* Function Name: reverse_TriggerStart
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_TriggerStart(void)             
{
    Cy_TCPWM_TriggerStart(reverse_HW, reverse_CNT_MASK);
}


/*******************************************************************************
* Function Name: reverse_TriggerReload
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerReloadOrIndex() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_TriggerReload(void)     
{
    Cy_TCPWM_TriggerReloadOrIndex(reverse_HW, reverse_CNT_MASK);
}


/*******************************************************************************
* Function Name: reverse_TriggerKill
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerStopOrKill() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_TriggerKill(void)
{
    Cy_TCPWM_TriggerStopOrKill(reverse_HW, reverse_CNT_MASK);
}


/*******************************************************************************
* Function Name: reverse_TriggerSwap
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerCaptureOrSwap() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_TriggerSwap(void)     
{
    Cy_TCPWM_TriggerCaptureOrSwap(reverse_HW, reverse_CNT_MASK);
}


/*******************************************************************************
* Function Name: reverse_GetInterruptStatus
****************************************************************************//**
*
* Invokes the Cy_TCPWM_GetInterruptStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetInterruptStatus(void)       
{
    return(Cy_TCPWM_GetInterruptStatus(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_ClearInterrupt
****************************************************************************//**
*
* Invokes the Cy_TCPWM_ClearInterrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_ClearInterrupt(uint32_t source)     
{
    Cy_TCPWM_ClearInterrupt(reverse_HW, reverse_CNT_NUM, source);
}


/*******************************************************************************
* Function Name: reverse_SetInterrupt
****************************************************************************//**
*
* Invokes the Cy_TCPWM_SetInterrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetInterrupt(uint32_t source)
{
    Cy_TCPWM_SetInterrupt(reverse_HW, reverse_CNT_NUM, source);
}


/*******************************************************************************
* Function Name: reverse_SetInterruptMask
****************************************************************************//**
*
* Invokes the Cy_TCPWM_SetInterruptMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void reverse_SetInterruptMask(uint32_t mask)     
{
    Cy_TCPWM_SetInterruptMask(reverse_HW, reverse_CNT_NUM, mask);
}


/*******************************************************************************
* Function Name: reverse_GetInterruptMask
****************************************************************************//**
*
* Invokes the Cy_TCPWM_GetInterruptMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetInterruptMask(void)         
{
    return(Cy_TCPWM_GetInterruptMask(reverse_HW, reverse_CNT_NUM));
}


/*******************************************************************************
* Function Name: reverse_GetInterruptStatusMasked
****************************************************************************//**
*
* Invokes the Cy_TCPWM_GetInterruptStatusMasked() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t reverse_GetInterruptStatusMasked(void)
{
    return(Cy_TCPWM_GetInterruptStatusMasked(reverse_HW, reverse_CNT_NUM));
}

#endif /* reverse_CY_TCPWM_PWM_PDL_H */


/* [] END OF FILE */
