/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#include "project.h"
#include "stdio_user.h"
#include <device01.h>
#include "Adafruit_NFCShield_I2C01.h"
#include "stdio.h"
#include "string.h"
#include <stdlib.h>

#define ARRAYLENGTH 32
char user[ARRAYLENGTH] = {0};

/* Macros used to store commands */
#define RTC_CMD_GET_DATE_TIME   ('1')
#define RTC_CMD_SET_DATE_TIME   ('2')

#define MAX_LENGTH              (4u)
#define VALID_DAY_LENGTH        (2u)
#define VALID_MONTH_LENGTH      (2u)
#define VALID_SHORT_YEAR_LENGTH (2u)
#define VALID_LONG_YEAR_LENGTH  (4u)


struct Patient
{
    char PatName[ARRAYLENGTH];
    char PatRoom[ARRAYLENGTH];
    char PatCube[ARRAYLENGTH];
    char PatTime[ARRAYLENGTH];
};

struct Patient Patient1;

uint8 success = 1;
uint8 uid[] = {0, 0, 0, 0, 0, 0, 0 };
uint8 uidLength;

#define HIGH        1
#define LOW         0

int state = 0;

void RFID_Read(void);
void data_Grab(char Patient[]);
void UserInterface(void);
static void SetDateTime(void);
static bool ValidateDateTime(uint32_t year, uint32_t month, uint32_t date, \
            uint32_t sec, uint32_t min, uint32_t hour);
static inline bool IsLeapYear(uint32_t );
