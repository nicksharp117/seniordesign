/*
* Software License Agreement (BSD License)
* 
* Copyright (c) 2012, Adafruit Industries
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 1. Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
* 3. Neither the name of the copyright holders nor the
* names of its contributors may be used to endorse or promote products
* derived from this software without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* 
* Retrieved from https://github.com/adafruit/Adafruit_NFCShield_I2C on 10-Aug-2013
* 
* 12-Aug-2013: Modifed by CJ Cullen for compatibility with Cypress PSoC 4
* 
*/

#include "Adafruit_NFCShield_I2C.h"

//#include "I2C_I2C.h"
//#include "irq_pin.h"


cy_stc_scb_i2c_master_xfer_config_t masterTransferCfg =
    {
        .slaveAddress = PN532_I2C_ADDRESS,
        .buffer       = NULL,
        .bufferSize   = 0U,
        .xferPending  = false
    };

static uint8    pn532ack[] =                    {0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00};
static uint8    pn532response_firmwarevers[] =  {0x00, 0xFF, 0x06, 0xFA, 0xD5, 0x03};
#define PN532_PACKBUFFSIZ 64
static uint8    pn532_packetbuffer[PN532_PACKBUFFSIZ];

static uint8    _uid[7];        // ISO14443A uid
static uint8    _uidLen;        // uid len
static uint8    _key[6];        // Mifare Classic key
static uint8    inListedTag;    // Tg number of inlisted tag.

static int      readackframe(void);
static uint8    wirereadstatus(void);
static void     wirereaddata(uint8* buff, uint8 n);
static void     wiresendcommand(uint8* cmd, uint8 cmdlen);
static int      waitUntilReady(uint16 timeout);

// Generic PN532 functions
int SAMConfig(void) {
    pn532_packetbuffer[0] = PN532_COMMAND_SAMCONFIGURATION;
    pn532_packetbuffer[1] = 0x01; // normal mode;
    pn532_packetbuffer[2] = 0x14; // timeout 50ms * 20 = 1 second
    pn532_packetbuffer[3] = 0x01; // use IRQ pin!
    
    if (!sendCommandCheckAck(pn532_packetbuffer, 4, 1000))
        return 0;

    // read data packet
    wirereaddata(pn532_packetbuffer, 8);
  
    return (pn532_packetbuffer[6] == 0x15);
}

uint32 getFirmwareVersion() {
    uint32 response;
    
    pn532_packetbuffer[0] = PN532_COMMAND_GETFIRMWAREVERSION;
    
    if (! sendCommandCheckAck(pn532_packetbuffer, 1, 1000))
        return 0;
	
    // read data packet
    wirereaddata(pn532_packetbuffer, 12);
    
    // check some basic stuff
    if (0 != strncmp((char *)pn532_packetbuffer, (char *)pn532response_firmwarevers, 6))
    {
        return 0;
    }
    
    response = pn532_packetbuffer[7];
    response <<= 8;
    response |= pn532_packetbuffer[8];
    response <<= 8;
    response |= pn532_packetbuffer[9];
    response <<= 8;
    response |= pn532_packetbuffer[10];
    
    return response;
}

int sendCommandCheckAck(uint8 *cmd, uint8 cmdlen, uint16 timeout) {
    // write the command
    wiresendcommand(cmd, cmdlen);
    
    if (!waitUntilReady(timeout))
        return 0;
    
        // read acknowledgement
    if (!readackframe())
    {
        return 0;
    }
    
    return 1; // ack'd command   
}

int setPassiveActivationRetries(uint8_t maxRetries) {
    pn532_packetbuffer[0] = PN532_COMMAND_RFCONFIGURATION;
    pn532_packetbuffer[1] = 5;    // Config item 5 (MaxRetries)
    pn532_packetbuffer[2] = 0xFF; // MxRtyATR (default = 0xFF)
    pn532_packetbuffer[3] = 0x01; // MxRtyPSL (default = 0x01)
    pn532_packetbuffer[4] = maxRetries;

    if (! sendCommandCheckAck(pn532_packetbuffer, 5, 1000))
        return 0x0;  // no ACK
    
    return 1;
}


// ISO14443A functions
int inListPassiveTarget() {
    pn532_packetbuffer[0] = PN532_COMMAND_INLISTPASSIVETARGET;
    pn532_packetbuffer[1] = 1;
    pn532_packetbuffer[2] = 0;
  
    if (!sendCommandCheckAck(pn532_packetbuffer,3,1000))
    {
        return 0;
    }
    
    if (!waitUntilReady(30000))
    {
        return 0;
    }
    
    wirereaddata(pn532_packetbuffer,sizeof(pn532_packetbuffer));
    
    if (pn532_packetbuffer[0] == 0 && pn532_packetbuffer[1] == 0 && pn532_packetbuffer[2] == 0xff)
    {
        uint8_t length = pn532_packetbuffer[3];
        if (pn532_packetbuffer[4]!=(uint8_t)(~length+1))
        {
            return 0;
        }
        if (pn532_packetbuffer[5]==PN532_PN532TOHOST && pn532_packetbuffer[6]==PN532_RESPONSE_INLISTPASSIVETARGET) {
            if (pn532_packetbuffer[7] != 1)
            {
                return 0;
            }
      
            inListedTag = pn532_packetbuffer[8];
      
            return 1;
        }
        else
        {
            return 0;
        } 
    } 
    else
    {
        return 0;
    }
    
    return 1;
}

int readPassiveTargetID(uint8 cardbaudrate, uint8 * uid, uint8 * uidLength) {
    uint8 i;
    pn532_packetbuffer[0] = PN532_COMMAND_INLISTPASSIVETARGET;
    pn532_packetbuffer[1] = 1;  // max 1 cards at once (we can set this to 2 later)
    pn532_packetbuffer[2] = cardbaudrate;
    
    if (! sendCommandCheckAck(pn532_packetbuffer, 3, 1000))
    {
        return 0x0;  // no cards read
    }
    
    // Wait for a card to enter the field
    waitUntilReady(200);

    // read data packet
    wirereaddata(pn532_packetbuffer, 20);
    
    // check some basic stuff
    /* ISO14443A card response should be in the following format:
  
    byte            Description
    -------------   ------------------------------------------
    b0..6           Frame header and preamble
    b7              Tags Found
    b8              Tag Number (only one used in this example)
    b9..10          SENS_RES
    b11             SEL_RES
    b12             NFCID Length
    b13..NFCIDLen   NFCID                                      */
  
    if (pn532_packetbuffer[7] != 1) 
        return 0;
    
    uint16 sens_res = pn532_packetbuffer[9];
    sens_res <<= 8;
    sens_res |= pn532_packetbuffer[10];
    
    /* Card appears to be Mifare Classic */
    *uidLength = pn532_packetbuffer[12];
    
    for (i=0; i < pn532_packetbuffer[12]; i++) 
    {
        uid[i] = pn532_packetbuffer[13+i];
    }

    return 1;
}

int inDataExchange(uint8 * send, uint8 sendLength, uint8 * response, uint8 * responseLength) {
    if (sendLength > PN532_PACKBUFFSIZ -2)
    {
        return 0;
    }
    uint8 i;
    
    pn532_packetbuffer[0] = 0x40; // PN532_COMMAND_INDATAEXCHANGE;
    pn532_packetbuffer[1] = inListedTag;
    for (i=0; i<sendLength; ++i)
    {
        pn532_packetbuffer[i+2] = send[i];
    }
  
    if (!sendCommandCheckAck(pn532_packetbuffer,sendLength+2,1000))
    {
        return 0;
    }
    
    if (!waitUntilReady(1000))
    {
        return 0;
    }
    
    wirereaddata(pn532_packetbuffer,sizeof(pn532_packetbuffer));
  
    if (pn532_packetbuffer[0] == 0 && pn532_packetbuffer[1] == 0 && pn532_packetbuffer[2] == 0xff)
    {
        uint8_t length = pn532_packetbuffer[3];
        if (pn532_packetbuffer[4]!=(uint8_t)(~length+1))
        {
            return 0;
        }
        if (pn532_packetbuffer[5]==PN532_PN532TOHOST && pn532_packetbuffer[6]==PN532_RESPONSE_INDATAEXCHANGE)
        {
            if ((pn532_packetbuffer[7] & 0x3f)!=0)
            {
                return 0;
            }
      
            length -= 3;
            
            if (length > *responseLength)
            {
                length = *responseLength; // silent truncation...
            }
            
            for (i=0; i<length; ++i)
            {
                response[i] = pn532_packetbuffer[8+i];
            }
            *responseLength = length;
            
            return 1;
        } 
        else
        {
            return 0;
        } 
    } 
    else
    {
        return 0;
    }
}


// Mifare Classic functions
int mifareclassic_IsFirstBlock (uint32 uiBlock) {
    // Test if we are in the small or big sectors
    if (uiBlock < 128)
        return ((uiBlock) % 4 == 0);
    else
        return ((uiBlock) % 16 == 0);
}

int mifareclassic_IsTrailerBlock (uint32 uiBlock) {
    // Test if we are in the small or big sectors
    if (uiBlock < 128)
        return ((uiBlock + 1) % 4 == 0);
    else
        return ((uiBlock + 1) % 16 == 0);
}

uint8 mifareclassic_AuthenticateBlock (uint8 * uid, uint8 uidLen, uint32 blockNumber, uint8 keyNumber, uint8 * keyData) {
    uint8 i;
    
    // Hang on to the key and uid data
    memcpy (_key, keyData, 6); 
    memcpy (_uid, uid, uidLen); 
    _uidLen = uidLen;

    // Prepare the authentication command //
    pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;   /* Data Exchange Header */
    pn532_packetbuffer[1] = 1;                              /* Max card numbers */
    pn532_packetbuffer[2] = (keyNumber) ? MIFARE_CMD_AUTH_B : MIFARE_CMD_AUTH_A;
    pn532_packetbuffer[3] = blockNumber;                    /* Block Number (1K = 0..63, 4K = 0..255 */
    memcpy (pn532_packetbuffer+4, _key, 6);
    for (i = 0; i < _uidLen; i++)
    {
        pn532_packetbuffer[10+i] = _uid[i];                /* 4 byte card ID */
    }
    
    if (! sendCommandCheckAck(pn532_packetbuffer, 10+_uidLen, 1000))
        return 0;
    
    // Read the response packet
    wirereaddata(pn532_packetbuffer, 12);
    
    // Check if the response is valid and we are authenticated???
    // for an auth success it should be bytes 5-7: 0xD5 0x41 0x00
    // Mifare auth error is technically byte 7: 0x14 but anything other and 0x00 is not good
    if (pn532_packetbuffer[7] != 0x00)
    {
        return 0;
    }  
    
    return 1;
}

uint8 mifareclassic_ReadDataBlock (uint8 blockNumber, uint8 * data) {
    /* Prepare the command */
    pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
    pn532_packetbuffer[1] = 1;                      /* Card number */
    pn532_packetbuffer[2] = MIFARE_CMD_READ;        /* Mifare Read command = 0x30 */
    pn532_packetbuffer[3] = blockNumber;            /* Block Number (0..63 for 1K, 0..255 for 4K) */

    /* Send the command */
    if (! sendCommandCheckAck(pn532_packetbuffer, 4, 1000))
    {
        return 0;
    }
    
    /* Read the response packet */
    wirereaddata(pn532_packetbuffer, 26);
    
    /* If byte 8 isn't 0x00 we probably have an error */
    if (pn532_packetbuffer[7] != 0x00)
    {
        return 0;
    }
    
    /* Copy the 16 data bytes to the output buffer        */
    /* Block content starts at byte 9 of a valid response */
    memcpy (data, pn532_packetbuffer+8, 16);
    
    return 1;  
}

uint8 mifareclassic_WriteDataBlock (uint8 blockNumber, uint8 * data) {
    /* Prepare the first command */
    pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
    pn532_packetbuffer[1] = 1;                      /* Card number */
    pn532_packetbuffer[2] = MIFARE_CMD_WRITE;       /* Mifare Write command = 0xA0 */
    pn532_packetbuffer[3] = blockNumber;            /* Block Number (0..63 for 1K, 0..255 for 4K) */
    memcpy (pn532_packetbuffer+4, data, 16);        /* Data Payload */
    
    /* Send the command */
    if (! sendCommandCheckAck(pn532_packetbuffer, 20, 1000))
    {
        return 0;
    }  
    CyDelay(10);
    
    /* Read the response packet */
    wirereaddata(pn532_packetbuffer, 26);
    
    return 1;  
}

uint8 mifareclassic_FormatNDEF (void) {
    uint8 sectorbuffer1[16] = {0x14, 0x01, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1};
    uint8 sectorbuffer2[16] = {0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1, 0x03, 0xE1};
    uint8 sectorbuffer3[16] = {0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0x78, 0x77, 0x88, 0xC1, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    
    // Note 0xA0 0xA1 0xA2 0xA3 0xA4 0xA5 must be used for key A
    // for the MAD sector in NDEF records (sector 0)
    
    // Write block 1 and 2 to the card
    if (!(mifareclassic_WriteDataBlock (1, sectorbuffer1)))
        return 0;
    if (!(mifareclassic_WriteDataBlock (2, sectorbuffer2)))
        return 0;
    // Write key A and access rights card
    if (!(mifareclassic_WriteDataBlock (3, sectorbuffer3)))
        return 0;
    
    // Seems that everything was OK (?!)
    return 1;
}

uint8 mifareclassic_WriteNDEFURI (uint8 sectorNumber, uint8 uriIdentifier, const char * url) {
    // Figure out how long the string is
    uint8 len = strlen(url);
    
    // Make sure we're within a 1K limit for the sector number
    if ((sectorNumber < 1) || (sectorNumber > 15))
        return 0;
    
    // Make sure the URI payload is between 1 and 38 chars
    if ((len < 1) || (len > 38))
        return 0;
    
    // Note 0xD3 0xF7 0xD3 0xF7 0xD3 0xF7 must be used for key A
    // in NDEF records
	
    // Setup the sector buffer (w/pre-formatted TLV wrapper and NDEF message)
    uint8 sectorbuffer1[16] = {0x00, 0x00, 0x03, len+5, 0xD1, 0x01, len+1, 0x55, uriIdentifier, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8 sectorbuffer2[16] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8 sectorbuffer3[16] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8 sectorbuffer4[16] = {0xD3, 0xF7, 0xD3, 0xF7, 0xD3, 0xF7, 0x7F, 0x07, 0x88, 0x40, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    if (len <= 6)
    {
        // Unlikely we'll get a url this short, but why not ...
        memcpy (sectorbuffer1+9, url, len);
        sectorbuffer1[len+9] = 0xFE;
    }
    else if (len == 7)
    {
        // 0xFE needs to be wrapped around to next block
        memcpy (sectorbuffer1+9, url, len);
        sectorbuffer2[0] = 0xFE;
    }
    else if ((len > 7) || (len <= 22))
    {
        // Url fits in two blocks
        memcpy (sectorbuffer1+9, url, 7);
        memcpy (sectorbuffer2, url+7, len-7);
        sectorbuffer2[len-7] = 0xFE;
    }
    else if (len == 23)
    {
        // 0xFE needs to be wrapped around to final block
        memcpy (sectorbuffer1+9, url, 7);
        memcpy (sectorbuffer2, url+7, len-7);
        sectorbuffer3[0] = 0xFE;
    }
    else
    {
        // Url fits in three blocks
        memcpy (sectorbuffer1+9, url, 7);
        memcpy (sectorbuffer2, url+7, 16);
        memcpy (sectorbuffer3, url+23, len-24);
        sectorbuffer3[len-22] = 0xFE;
    }
  
    // Now write all three blocks back to the card
    if (!(mifareclassic_WriteDataBlock (sectorNumber*4, sectorbuffer1)))
        return 0;
    if (!(mifareclassic_WriteDataBlock ((sectorNumber*4)+1, sectorbuffer2)))
        return 0;
    if (!(mifareclassic_WriteDataBlock ((sectorNumber*4)+2, sectorbuffer3)))
        return 0;
    if (!(mifareclassic_WriteDataBlock ((sectorNumber*4)+3, sectorbuffer4)))
        return 0;
    
    // Seems that everything was OK (?!)
    return 1;
}

// Mifare Ultralight functions
uint8 mifareultralight_ReadPage (uint8 page, uint8 * buffer) {
    if (page >= 64)
    {
        return 0;
    }

    /* Prepare the command */
    pn532_packetbuffer[0] = PN532_COMMAND_INDATAEXCHANGE;
    pn532_packetbuffer[1] = 1;                   /* Card number */
    pn532_packetbuffer[2] = MIFARE_CMD_READ;     /* Mifare Read command = 0x30 */
    pn532_packetbuffer[3] = page;                /* Page Number (0..63 in most cases) */
    
    /* Send the command */
    if (! sendCommandCheckAck(pn532_packetbuffer, 4, 1000))
    {
        return 0;
    }
    
    /* Read the response packet */
    wirereaddata(pn532_packetbuffer, 26);

    /* If byte 8 isn't 0x00 we probably have an error */
    if (pn532_packetbuffer[7] == 0x00)
    {
        /* Copy the 4 data bytes to the output buffer         */
        /* Block content starts at byte 9 of a valid response */
        /* Note that the command actually reads 16 byte or 4  */
        /* pages at a time ... we simply discard the last 12  */
        /* bytes                                              */
        memcpy (buffer, pn532_packetbuffer+8, 4);
    }
    else
    {
        return 0;
    }
    
    /* Display data for debug if requested */

    // Return OK signal
    return 1;
}


// static functions
int readackframe(void) {
    uint8 ackbuff[6];
    
    wirereaddata(ackbuff, 6);
    
    return (0 == strncmp((char *)ackbuff, (char *)pn532ack, 6));
}

uint8 wirereadstatus(void) {
    uint8 x = Cy_GPIO_Read(irq_pin_PORT, irq_pin_NUM);
    
    if (x == 1)
        return PN532_I2C_BUSY;
    else
        return PN532_I2C_READY;
}

void wirereaddata(uint8* buff, uint8 n) {
    uint8 recBuff[64];
    
    
    CyDelay(2);
    
    waitUntilReady(1000);
    
    /* Structure for master transfer configuration */
//    cy_stc_scb_i2c_master_xfer_config_t masterTransferCfg =
//    {
//        .slaveAddress = PN532_I2C_ADDRESS,
//        .buffer       = recBuff,
//        .bufferSize   = n+2,
//        .xferPending  = false
//    };
    
    masterTransferCfg.buffer = recBuff;
    masterTransferCfg.bufferSize = n + 2;
    
    Cy_SCB_I2C_MasterRead(I2C_HW, &masterTransferCfg,&I2C_context);
    while(Cy_SCB_I2C_MasterGetStatus(I2C_HW, &I2C_context) == CY_SCB_I2C_MASTER_BUSY);

    memcpy(buff, &recBuff[1], n);
}

void wiresendcommand(uint8* cmd, uint8 cmdlen) {
    uint8 checksum, i;
    uint8 sendBuf[64];
    
    cmdlen++;
    
    CyDelay(2);     // or whatever the delay is for waking up the board
    
    checksum = (uint8)(PN532_PREAMBLE + PN532_PREAMBLE + PN532_STARTCODE2 + PN532_HOSTTOPN532);
    
    sendBuf[0] = PN532_PREAMBLE;
    sendBuf[1] = PN532_PREAMBLE;
    sendBuf[2] = PN532_STARTCODE2;
    sendBuf[3] = cmdlen;
    sendBuf[4] = ~cmdlen + 1;
    sendBuf[5] = PN532_HOSTTOPN532;
    
    for (i=0; i<cmdlen-1; i++)
    {
        sendBuf[6+i] = cmd[i];
        checksum += cmd[i];
    }
    
    sendBuf[cmdlen+5] = ~checksum;
    sendBuf[cmdlen+6] = PN532_POSTAMBLE;
    
    
    masterTransferCfg.buffer = sendBuf;
    masterTransferCfg.bufferSize = cmdlen+7;
    
    Cy_SCB_I2C_MasterWrite(I2C_HW, &masterTransferCfg, &I2C_context);
    while(Cy_SCB_I2C_MasterGetStatus(I2C_HW, &I2C_context) == CY_SCB_I2C_MASTER_BUSY);
} 

int waitUntilReady(uint16 timeout) {
    uint16 timer = 0;
    while(wirereadstatus() != PN532_I2C_READY)
    {
        if (timeout != 0)
        {
            timer += 10;
            if (timer > timeout)
            {
                return 0;
            }
        }
        CyDelay(10);
    }
    return 1;
}

/* [] END OF FILE */
