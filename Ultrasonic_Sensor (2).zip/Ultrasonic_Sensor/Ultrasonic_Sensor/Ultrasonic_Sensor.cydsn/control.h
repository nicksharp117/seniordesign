/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <device.h>
#include "Adafruit_NFCShield_I2C.h"
#include "stdio.h"
#include "string.h"

/* Constant Variables ----------------------------------------------------------------------- */
#define MOTORPOWER  65000
#define MOTORWALL   30000
#define TURNDIST    1500
#define STOPDIST    2000
#define WALLCLOSE   3000
#define WALLFAR     3000
#define RIGHT       2
#define LEFT        1
#define ARRAYLENGTH 32
#define HIGH        1
#define LOW         0
enum ID{Name, Room, Cube, Time};
enum steps{step1, step2, step3, step4, step5, step6, step7, none};

struct Patient
{
    char PatName[ARRAYLENGTH];
    char PatRoom[ARRAYLENGTH];
    char PatCube[ARRAYLENGTH];
    char PatTime[ARRAYLENGTH];
};

struct Patient Patient1;

/* Global Variables ------------------------------------------------------------------------- */
int time = 0;
int time_two = 0;
int time_three = 0;
int total_Turns_One = 0;
int total_Turns_Two = 0;
int count_one = 0;
int count_two = 0;
int count_three = 0;

uint8 success = 1;
uint8 uid[] = {0, 0, 0, 0, 0, 0, 0 };
uint8 uidLength;

int array1[32];
int array1count = 0;
int array2[32];
int array2count = 0;
int array3[32];
int array3count = 0;

// First room
const int firstroom[32] = {14,0,1,92,0,1,310,0,2,50,'\0'};
const int firstside[32] = {0,0,0,LEFT,0,0,LEFT,0,0,0,0};


enum steps cycle = none;
int direction = 0;

char user[ARRAYLENGTH] = {0};

/* Function Decleration --------------------------------------------------------------------- */
void clear_array(char send[]);
void clear_sensors(void);
void turn90(int direction);
void forward(void);
void stop(void);
void godirection(const int distance[], int direction, const int wall[]);
void wallcheck(const int wall[]);
void obstructioncheck(const int wall[]);
int average(int array1[], int arraycount, int ultra_num);
int powerlevel(float wall);
void RFID_Read(void);
